#include <iostream>

#include "Lib.h"

void printer()
{
    std::cout << "Hello World!!!" << std::endl;
}
