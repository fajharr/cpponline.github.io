#include <iostream>

#include "Lib.h"

int main()
{
    printer();

    return 0;
}
