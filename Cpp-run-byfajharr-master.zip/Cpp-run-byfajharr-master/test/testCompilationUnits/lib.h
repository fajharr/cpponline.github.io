#ifndef LIB_H
#define LIB_H

void testFunc();

#endif
