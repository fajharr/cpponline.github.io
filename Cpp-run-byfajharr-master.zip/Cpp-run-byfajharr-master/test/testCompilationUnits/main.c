#include <stdio.h>

#include "lib.h"

int main()
{
    printf("Before...\n");
    testFunc();
    printf("After...\n");
}
