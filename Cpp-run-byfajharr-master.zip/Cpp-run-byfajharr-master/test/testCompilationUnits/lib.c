#include <stdio.h>

void testFunc()
{
    printf("Test succeeded.\n");
}
